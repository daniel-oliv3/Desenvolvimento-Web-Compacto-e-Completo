<?php

// configuration file
define('MYSQL_CONFIG', [
    'host' => 'localhost',
    'database' => 'php_pdo_contactos',
    'username' => 'user_php_pdo_contactos',
    'password' => 'd6VONaXIN8vA3ab5mogI3uYizuseFO',
]);